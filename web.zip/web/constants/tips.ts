export const tipPercents = [5, 10, 15, 20, 25];
