import { BASE_URL } from "constants/constants";

export default function getStoryImage(img: string) {
  // return BASE_URL + "/storage/" + img;
  return img;
}
