// import { IMAGE_URL } from "constants/constants";

export default function getImage(img?: string) {
  if (img) {
    return img;
  } else {
    return "";
  }
}
